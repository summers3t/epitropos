import {
    parseTropoAssistantTurn,
    TROPO_ASSISTANT_TURN_JSON_SCHEMA,
    type TropoAssistantTurn,
} from "@/lib/admin/tropoActionSchemas";

type TropoChatMessage = {
    role: "user" | "assistant";
    content: string;
};

type ResponsesPayload = {
    output?: Array<{
        type?: string;
        content?: Array<{
            type?: string;
            text?: string;
            refusal?: string;
        }>;
    }>;
    error?: {
        message?: string;
        code?: string;
        type?: string;
    };
};

export type TropoProviderName = "groq" | "openai";

export type TropoProviderUsage = {
    requestsLimit: string | null;
    requestsRemaining: string | null;
    requestsReset: string | null;
    tokensLimit: string | null;
    tokensRemaining: string | null;
    tokensReset: string | null;
    retryAfterSeconds: number | null;
};

export type TropoCompletionResult = {
    reply: string;
    provider: TropoProviderName;
    model: string;
    proposedActions: TropoAssistantTurn["proposed_actions"];
    usage: TropoProviderUsage;
};

export class TropoProviderError extends Error {
    status: number;
    provider: TropoProviderName | "configuration";
    retryAfterSeconds: number | null;
    usage: TropoProviderUsage | null;

    constructor(
        message: string,
        options: {
            status: number;
            provider: TropoProviderName | "configuration";
            retryAfterSeconds?: number | null;
            usage?: TropoProviderUsage | null;
        },
    ) {
        super(message);
        this.name = "TropoProviderError";
        this.status = options.status;
        this.provider = options.provider;
        this.retryAfterSeconds = options.retryAfterSeconds ?? null;
        this.usage = options.usage ?? null;
    }
}

type ProviderConfig = {
    provider: TropoProviderName;
    apiKey: string;
    endpoint: string;
    model: string;
};

type ProviderRequestOptions = {
    useStructuredFormat: boolean;
};

type ProviderSuccessResponse = {
    text: string;
    usage: TropoProviderUsage;
};

type ProviderStructuredFormatRetryResponse = {
    shouldRetryWithoutStructuredFormat: true;
};

type ProviderResponse = ProviderSuccessResponse | ProviderStructuredFormatRetryResponse;

function normalizeProvider(value: string | undefined): TropoProviderName {
    const normalized = value?.trim().toLowerCase() || "groq";

    if (normalized === "groq" || normalized === "openai") {
        return normalized;
    }

    throw new TropoProviderError(
        `Unsupported TROPO_AI_PROVIDER value: ${normalized}. Use "groq" or "openai".`,
        {
            status: 503,
            provider: "configuration",
        },
    );
}

function readProviderConfig(): ProviderConfig {
    const provider = normalizeProvider(process.env.TROPO_AI_PROVIDER);
    const commonModel = process.env.TROPO_AI_MODEL?.trim();

    if (provider === "groq") {
        const apiKey = process.env.GROQ_API_KEY?.trim();

        if (!apiKey) {
            throw new TropoProviderError(
                "Tropo is configured for Groq, but GROQ_API_KEY is missing on this environment.",
                {
                    status: 503,
                    provider: "configuration",
                },
            );
        }

        return {
            provider,
            apiKey,
            endpoint: "https://api.groq.com/openai/v1/responses",
            model:
                commonModel ||
                process.env.GROQ_PROJECT_ASSISTANT_MODEL?.trim() ||
                "openai/gpt-oss-120b",
        };
    }

    const apiKey = process.env.OPENAI_API_KEY?.trim();

    if (!apiKey) {
        throw new TropoProviderError(
            "Tropo is configured for OpenAI, but OPENAI_API_KEY is missing on this environment.",
            {
                status: 503,
                provider: "configuration",
            },
        );
    }

    return {
        provider,
        apiKey,
        endpoint: "https://api.openai.com/v1/responses",
        model:
            commonModel ||
            process.env.OPENAI_PROJECT_ASSISTANT_MODEL?.trim() ||
            "gpt-5.4-mini",
    };
}

function extractResponseText(payload: ResponsesPayload) {
    const parts: string[] = [];

    for (const item of payload.output ?? []) {
        if (item.type !== "message") continue;

        for (const content of item.content ?? []) {
            if (content.type === "output_text" && content.text) {
                parts.push(content.text);
            }

            if (content.type === "refusal" && content.refusal) {
                parts.push(content.refusal);
            }
        }
    }

    return parts.join("\n\n").trim();
}

function parseRetryAfter(value: string | null) {
    if (!value) return null;
    const seconds = Number(value);
    return Number.isFinite(seconds) && seconds >= 0 ? seconds : null;
}

function readRateLimitUsage(headers: Headers, retryAfterSeconds: number | null = null): TropoProviderUsage {
    return {
        requestsLimit: headers.get("x-ratelimit-limit-requests"),
        requestsRemaining: headers.get("x-ratelimit-remaining-requests"),
        requestsReset: headers.get("x-ratelimit-reset-requests"),
        tokensLimit: headers.get("x-ratelimit-limit-tokens"),
        tokensRemaining: headers.get("x-ratelimit-remaining-tokens"),
        tokensReset: headers.get("x-ratelimit-reset-tokens"),
        retryAfterSeconds,
    };
}

function emptyRateLimitUsage(): TropoProviderUsage {
    return {
        requestsLimit: null,
        requestsRemaining: null,
        requestsReset: null,
        tokensLimit: null,
        tokensRemaining: null,
        tokensReset: null,
        retryAfterSeconds: null,
    };
}

function providerLabel(provider: TropoProviderName) {
    return provider === "groq" ? "Groq" : "OpenAI";
}

function isStructuredFormatRejection(status: number, providerMessage: string | undefined) {
    if (status !== 400 && status !== 422) return false;
    const message = providerMessage?.toLowerCase() ?? "";
    return (
        message.includes("schema") ||
        message.includes("structured") ||
        message.includes("format") ||
        message.includes("text") ||
        message.includes("unsupported") ||
        message.includes("invalid")
    );
}

async function callProvider(
    config: ProviderConfig,
    args: {
        instructions: string;
        messages: TropoChatMessage[];
    },
    options: ProviderRequestOptions,
): Promise<ProviderResponse> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 70_000);

    const requestBody: Record<string, unknown> = {
        model: config.model,
        instructions: args.instructions,
        input: args.messages.map((message) => ({
            role: message.role,
            content: message.content,
        })),
        reasoning: { effort: "low" },
        max_output_tokens: 1200,
    };

    if (options.useStructuredFormat) {
        requestBody.text = {
            format: {
                type: "json_schema",
                name: "tropo_assistant_turn",
                schema: TROPO_ASSISTANT_TURN_JSON_SCHEMA,
                strict: true,
            },
        };
    }

    // Groq's Responses API rejects OpenAI's `store` field.
    if (config.provider === "openai") {
        requestBody.store = false;
    }

    try {
        const response = await fetch(config.endpoint, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${config.apiKey}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(requestBody),
            cache: "no-store",
            signal: controller.signal,
        });

        const rawBody = await response.text();
        let payload: ResponsesPayload = {};

        if (rawBody) {
            try {
                payload = JSON.parse(rawBody) as ResponsesPayload;
            } catch {
                payload = {};
            }
        }

        if (!response.ok) {
            const retryAfterSeconds = parseRetryAfter(response.headers.get("retry-after"));
            const usage = readRateLimitUsage(response.headers, retryAfterSeconds);
            const providerMessage = payload.error?.message?.trim();
            const label = providerLabel(config.provider);

            if (options.useStructuredFormat && isStructuredFormatRejection(response.status, providerMessage)) {
                return { shouldRetryWithoutStructuredFormat: true as const };
            }

            if (response.status === 429) {
                const retryText =
                    retryAfterSeconds === null
                        ? "Please wait briefly and try again."
                        : `Try again in about ${Math.max(1, Math.ceil(retryAfterSeconds))} seconds.`;

                throw new TropoProviderError(`${label} rate limit reached. ${retryText}`, {
                    status: 429,
                    provider: config.provider,
                    retryAfterSeconds,
                    usage,
                });
            }

            throw new TropoProviderError(
                providerMessage
                    ? `${label} request failed: ${providerMessage}`
                    : `${label} request failed`,
                {
                    status: response.status,
                    provider: config.provider,
                    usage,
                },
            );
        }

        const text = extractResponseText(payload);

        if (!text) {
            throw new TropoProviderError(`${providerLabel(config.provider)} returned an empty response`, {
                status: 502,
                provider: config.provider,
            });
        }

        return { text, usage: readRateLimitUsage(response.headers) };
    } catch (error) {
        if (error instanceof TropoProviderError) throw error;

        if (error instanceof Error && error.name === "AbortError") {
            throw new TropoProviderError(`${providerLabel(config.provider)} request timed out`, {
                status: 504,
                provider: config.provider,
            });
        }

        throw new TropoProviderError(
            error instanceof Error
                ? `${providerLabel(config.provider)} request failed: ${error.message}`
                : `${providerLabel(config.provider)} request failed`,
            {
                status: 502,
                provider: config.provider,
            },
        );
    } finally {
        clearTimeout(timeoutId);
    }
}

export async function requestTropoCompletion(args: {
    instructions: string;
    messages: TropoChatMessage[];
}): Promise<TropoCompletionResult> {
    const config = readProviderConfig();
    let response = await callProvider(config, args, { useStructuredFormat: true });

    if ("shouldRetryWithoutStructuredFormat" in response) {
        response = await callProvider(config, args, { useStructuredFormat: false });
    }

    if (!("text" in response) || typeof response.text !== "string" || !response.text.trim()) {
        throw new TropoProviderError(`${providerLabel(config.provider)} did not return a usable response`, {
            status: 502,
            provider: config.provider,
        });
    }

    const responseText = response.text;
    const parsed = parseTropoAssistantTurn(responseText);

    return {
        reply: parsed.reply,
        proposedActions: parsed.proposed_actions,
        provider: config.provider,
        model: config.model,
        usage: response.usage ?? emptyRateLimitUsage(),
    };
}
